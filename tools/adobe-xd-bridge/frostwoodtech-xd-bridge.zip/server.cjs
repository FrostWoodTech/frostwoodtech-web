"use strict";
const http = require("node:http");
const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const path = require("node:path");
const { validateJob } = require("./plugin/protocol.js");
const MAX_BODY = 16 * 1024 * 1024;
function fail(status, message) {
  const error = new Error(message);
  error.status = status;
  throw error;
}
function equalSecret(actual, expected) {
  const a = Buffer.from(actual || ""),
    b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
async function jsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) fail(413, "Request exceeds 16 MB.");
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch (_) {
    fail(400, "Invalid JSON.");
  }
}
function summary(job) {
  return {
    id: job.id,
    label: job.label,
    status: job.status,
    documentId: job.documentId,
    clientId: job.clientId,
    summary: job.summary,
    result: job.result,
    error: job.error,
    createdAt: job.createdAt,
  };
}
async function startBridge(options = {}) {
  const token = options.token || crypto.randomBytes(32).toString("hex");
  const jobs = new Map(),
    clients = new Map(),
    snapshots = new Map(),
    previews = new Map();
  let jobBytes = 0;
  const server = http.createServer(async (req, res) => {
    const send = (status, body) => {
      res.writeHead(status, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
      });
      res.end(JSON.stringify(body));
    };
    try {
      const port = server.address().port;
      if (req.headers.host !== "127.0.0.1:" + port)
        fail(403, "Only the loopback host is accepted.");
      // UXP requests have no browser CORS requirement; web pages cannot preflight this API.
      if (
        req.headers.origin &&
        req.headers.origin !== "null" &&
        !req.headers.origin.startsWith("file://")
      )
        fail(403, "Web origins cannot access the XD bridge.");
      if (!equalSecret(req.headers.authorization, "Bearer " + token))
        fail(401, "Invalid pairing key.");
      const url = new URL(req.url, "http://127.0.0.1:" + port);
      function client(id) {
        const value = clients.get(id);
        if (!value) fail(403, "Reconnect the XD document.");
        value.lastSeen = Date.now();
        return value;
      }
      if (req.method === "GET" && url.pathname === "/status")
        return send(200, {
          service: "frostwoodtech-xd-bridge",
          protocol: 1,
          clients: [...clients.values()],
          jobs: [...jobs.values()].map(summary),
          previews: [...previews.values()].map((p) => ({
            id: p.id,
            key: p.key,
            nodeId: p.nodeId,
            clientId: p.clientId,
          })),
        });
      if (req.method === "POST" && url.pathname === "/connect") {
        const data = await jsonBody(req);
        if (
          typeof data.documentId !== "string" ||
          !data.documentId ||
          data.documentId.length > 200 ||
          typeof data.name !== "string" ||
          data.name.length > 300
        )
          fail(400, "Invalid document identity.");
        if (clients.size >= 20)
          fail(409, "Restart the bridge to clear old connections.");
        const value = {
          clientId: crypto.randomUUID(),
          documentId: data.documentId,
          name: data.name,
          version: String(data.version || "").slice(0, 80),
          lastSeen: Date.now(),
        };
        clients.set(value.clientId, value);
        return send(200, value);
      }
      if (req.method === "POST" && url.pathname === "/jobs") {
        const data = await jsonBody(req);
        let counts;
        try {
          counts = validateJob(data);
        } catch (error) {
          fail(400, error.message);
        }
        const size = Buffer.byteLength(JSON.stringify(data));
        if (jobs.size >= 80 || jobBytes + size > 64 * 1024 * 1024)
          fail(
            409,
            "Batch storage is full. Restart the bridge after completing your work.",
          );
        const job = Object.assign({}, data, {
          id: crypto.randomUUID(),
          status: "queued",
          summary: counts,
          createdAt: new Date().toISOString(),
        });
        jobs.set(job.id, job);
        jobBytes += size;
        return send(201, summary(job));
      }
      if (req.method === "GET" && url.pathname === "/pending") {
        const value = client(url.searchParams.get("clientId"));
        const job = [...jobs.values()].find(
          (j) =>
            j.status === "queued" &&
            (!j.documentId || j.documentId === value.documentId),
        );
        return send(200, { job: job || null });
      }
      const match = /^\/jobs\/([a-f0-9-]+)(?:\/(claim|complete|fail))?$/.exec(
        url.pathname,
      );
      if (match) {
        const job = jobs.get(match[1]);
        if (!job) fail(404, "Batch not found.");
        if (req.method === "GET" && !match[2]) return send(200, summary(job));
        if (req.method !== "POST" || !match[2])
          fail(405, "Unsupported batch operation.");
        const data = await jsonBody(req),
          value = client(data.clientId);
        if (job.documentId && job.documentId !== value.documentId)
          fail(409, "Batch belongs to a different document.");
        if (match[2] === "claim") {
          if (job.status !== "queued")
            fail(
              409,
              "Batch is already claimed or finished. Inspect XD before retrying.",
            );
          job.status = "running";
          job.clientId = value.clientId;
          job.documentId = value.documentId;
        } else {
          if (job.status !== "running" || job.clientId !== value.clientId)
            fail(409, "Only the claiming XD connection can finish this batch.");
          if (match[2] === "complete") {
            job.status = "completed";
            job.result = data.result;
          } else {
            job.status = "failed";
            job.error = String(data.error || "XD operation failed").slice(
              0,
              2000,
            );
          }
        }
        return send(200, summary(job));
      }
      if (req.method === "POST" && url.pathname === "/snapshot") {
        const data = await jsonBody(req),
          value = client(data.clientId);
        if (data.documentId !== value.documentId || !Array.isArray(data.nodes))
          fail(400, "Invalid document report.");
        snapshots.set(value.clientId, {
          documentId: value.documentId,
          receivedAt: new Date().toISOString(),
          nodes: data.nodes,
        });
        return send(200, { ok: true });
      }
      if (req.method === "GET" && url.pathname === "/snapshot") {
        client(url.searchParams.get("clientId"));
        const value = snapshots.get(url.searchParams.get("clientId"));
        if (!value) fail(404, "Use Send layer report in the XD panel first.");
        return send(200, value);
      }
      if (req.method === "POST" && url.pathname === "/preview") {
        const data = await jsonBody(req),
          value = client(data.clientId);
        if (
          data.documentId !== value.documentId ||
          typeof data.nodeId !== "string" ||
          typeof data.key !== "string" ||
          !/^data:image\/png;base64,[A-Za-z0-9+/]+=*$/.test(data.dataUri)
        )
          fail(400, "Invalid artboard preview.");
        if (previews.size >= 40) previews.delete(previews.keys().next().value);
        const preview = {
          id: crypto.randomUUID(),
          key: data.key.slice(0, 100),
          nodeId: data.nodeId.slice(0, 200),
          clientId: value.clientId,
          bytes: Buffer.from(data.dataUri.split(",")[1], "base64"),
        };
        if (
          !preview.bytes
            .subarray(0, 8)
            .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
        )
          fail(400, "Preview is not a PNG.");
        previews.set(preview.id, preview);
        return send(201, { id: preview.id });
      }
      const previewMatch = /^\/previews\/([a-f0-9-]+)$/.exec(url.pathname);
      if (req.method === "GET" && previewMatch) {
        const value = previews.get(previewMatch[1]);
        if (!value) fail(404, "Preview not found.");
        res.writeHead(200, {
          "Content-Type": "image/png",
          "Cache-Control": "no-store",
        });
        return res.end(value.bytes);
      }
      fail(404, "Endpoint not found.");
    } catch (error) {
      if (!res.headersSent)
        send(error.status || 500, {
          error: error.status ? error.message : "Bridge request failed.",
        });
      else res.end();
    }
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(
      options.port === undefined ? 32189 : options.port,
      "127.0.0.1",
      resolve,
    );
  });
  const session = {
    baseUrl: "http://127.0.0.1:" + server.address().port,
    token: token,
    pid: process.pid,
  };
  if (options.stateDirectory) {
    try {
      await fs.mkdir(options.stateDirectory, { recursive: true });
      await fs.writeFile(
        path.join(options.stateDirectory, "session.json"),
        JSON.stringify(session),
        { mode: 0o600 },
      );
      await fs.writeFile(
        path.join(options.stateDirectory, "connection.local.txt"),
        "Paste this pairing key into the XD panel's Connect field. Do not put it in chat or Git.\n\n" +
          token +
          "\n",
        { mode: 0o600 },
      );
    } catch (error) {
      await new Promise((resolve) => server.close(resolve));
      throw error;
    }
  }
  return { server: server, session: session };
}
if (require.main === module) {
  const stateDirectory = path.join(__dirname, ".local");
  startBridge({ stateDirectory: stateDirectory })
    .then(({ server, session }) => {
      process.stdout.write(
        "Adobe XD bridge listening at " +
          session.baseUrl +
          "\nPairing key: open tools/adobe-xd-bridge/.local/connection.local.txt locally.\nNo XD document is connected until you load the plugin and click Connect document.\n",
      );
      let stopping = false;
      const stop = () => {
        if (stopping) return;
        stopping = true;
        server.close(() => process.exit(0));
        server.closeIdleConnections();
      };
      process.on("SIGINT", stop);
      process.on("SIGTERM", stop);
    })
    .catch((error) => {
      process.stderr.write("Could not start bridge: " + error.message + "\n");
      process.exitCode = 1;
    });
}
module.exports = { startBridge };
