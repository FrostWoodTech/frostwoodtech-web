"use strict";
const { validateJob } = require("./protocol.js");
const OWNER = "frostwoodtech-xd-bridge-v1";
function owned(node) {
  return node.pluginData && node.pluginData.owner === OWNER;
}
function children(node) {
  const list = [];
  if (node.children) node.children.forEach((child) => list.push(child));
  return list;
}
function position(node, x, y) {
  const bounds = node.localBounds;
  node.placeInParentCoordinates({ x: bounds.x, y: bounds.y }, { x: x, y: y });
}
function buildNode(spec, parent, sg, commands, selection, ox, oy, created) {
  if (spec.type === "group") {
    const items = spec.children.map((child) =>
      buildNode(
        child,
        parent,
        sg,
        commands,
        selection,
        ox + spec.x,
        oy + spec.y,
        created,
      ),
    );
    selection.items = items;
    commands.group();
    const group = selection.items[0];
    group.name = spec.name;
    if (spec.opacity !== undefined) group.opacity = spec.opacity;
    created.push(group.guid);
    return group;
  }
  let node;
  if (spec.type === "text") {
    node = new sg.Text();
    node.text = spec.text;
    node.fontFamily = spec.fontFamily;
    node.fontStyle = spec.fontStyle;
    node.fontSize = spec.fontSize;
    if (spec.width !== undefined)
      node.layoutBox = { type: sg.Text.AUTO_HEIGHT, width: spec.width };
    if (spec.lineHeight !== undefined) node.lineSpacing = spec.lineHeight;
    if (spec.letterSpacing !== undefined)
      node.charSpacing = (spec.letterSpacing * 1000) / spec.fontSize;
    if (spec.align)
      node.textAlign = {
        left: sg.Text.ALIGN_LEFT,
        center: sg.Text.ALIGN_CENTER,
        right: sg.Text.ALIGN_RIGHT,
      }[spec.align];
  } else if (spec.type === "ellipse") {
    node = new sg.Ellipse();
    node.radiusX = spec.width / 2;
    node.radiusY = spec.height / 2;
  } else if (spec.type === "path") {
    node = new sg.Path();
    node.pathData = spec.pathData;
  } else {
    node = new sg.Rectangle();
    node.width = spec.width;
    node.height = spec.height;
    if (spec.radius) node.setAllCornerRadii(spec.radius);
    if (spec.type === "image") node.fill = new sg.ImageFill(spec.dataUri);
  }
  node.name = spec.name;
  if (spec.fill) node.fill = new sg.Color(spec.fill);
  if (spec.stroke) {
    node.stroke = new sg.Color(spec.stroke);
    node.strokeWidth = spec.strokeWidth;
  }
  if (spec.opacity !== undefined) node.opacity = spec.opacity;
  parent.addChild(node);
  position(node, ox + spec.x, oy + spec.y);
  created.push(node.guid);
  return node;
}
function renderJob(job, root, selection, sg, commands) {
  validateJob(job);
  if (selection.editContext !== root)
    throw new Error(
      "Click the blank pasteboard outside all artboards, then Apply again. XD currently restricts edits to the selected container.",
    );
  const staged = [],
    previous = [],
    created = [];
  const existing = children(root);
  const anchor = existing.find(
    (node) => owned(node) && typeof node.pluginData.originX === "number",
  );
  const originX = anchor
    ? anchor.pluginData.originX
    : existing.length
      ? Math.max.apply(
          null,
          existing.map((node) => node.globalBounds.x + node.globalBounds.width),
        ) + 200
      : 0;
  try {
    job.artboards.forEach((spec) => {
      const matches = children(root).filter(
        (node) => owned(node) && node.pluginData.key === spec.key,
      );
      if (matches.length > 1)
        throw new Error(
          "Multiple bridge artboards have key " +
            spec.key +
            ". Resolve the duplicate in XD before updating.",
        );
      if (matches[0]) previous.push(matches[0]);
      const board = new sg.Artboard();
      board.name = spec.name;
      board.width = spec.width;
      board.height = spec.height;
      board.fill = new sg.Color(spec.fill);
      if (spec.viewportHeight) board.viewportHeight = spec.viewportHeight;
      board.pluginData = {
        owner: OWNER,
        key: spec.key,
        jobId: job.id,
        originX: originX,
      };
      root.addChild(board, 0);
      staged.push(board);
      created.push(board.guid);
      position(board, originX + spec.x, spec.y);
      spec.children.forEach((child) =>
        buildNode(child, board, sg, commands, selection, 0, 0, created),
      );
    });
    const replacedNodeIds = previous.map((node) => node.guid);
    previous.forEach((node) => node.removeFromParent());
    selection.items = staged;
    return {
      artboards: staged.map((node) => ({
        id: node.guid,
        key: node.pluginData.key,
        name: node.name,
        width: node.width,
        height: node.height,
      })),
      createdNodeIds: created,
      replacedNodeIds: replacedNodeIds,
    };
  } catch (error) {
    staged.forEach((node) => {
      if (node.parent) node.removeFromParent();
    });
    throw error;
  }
}
function snapshot(root) {
  function read(node) {
    const result = {
      id: node.guid,
      name: node.name,
      type: node.constructor.name,
      bounds: node.globalBounds,
    };
    if (node.constructor.name === "Text") {
      result.text = node.text;
      result.fontFamily = node.fontFamily;
      result.fontStyle = node.fontStyle;
      result.fontSize = node.fontSize;
      result.clipped = node.clippedByArea;
    }
    if (owned(node)) result.key = node.pluginData.key;
    if (node.children) result.children = children(node).map(read);
    return result;
  }
  return children(root).filter(owned).map(read);
}
module.exports = { renderJob, snapshot, owned, children, OWNER };
