/* Shared declarative protocol: intentionally no JavaScript execution or filesystem commands. */
"use strict";
const TYPES = ["rect", "ellipse", "text", "path", "image", "group"];
const MAX_NODES = 8000;
function assert(condition, message) {
  if (!condition) throw new Error(message);
}
function number(value, label, min, max) {
  assert(
    typeof value === "number" &&
      Number.isFinite(value) &&
      value >= min &&
      value <= max,
    label + " is outside its permitted range.",
  );
}
function color(value, label) {
  assert(
    typeof value === "string" && /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(value),
    label + " must be a hex color.",
  );
}
function validateJob(job) {
  assert(
    job && typeof job === "object" && !Array.isArray(job),
    "Expected a design batch.",
  );
  assert(
    job.kind === "render",
    "Only declarative render batches are supported.",
  );
  assert(
    typeof job.label === "string" &&
      job.label.length > 0 &&
      job.label.length <= 160,
    "A short batch label is required.",
  );
  assert(
    Array.isArray(job.artboards) &&
      job.artboards.length > 0 &&
      job.artboards.length <= 80,
    "Supply 1–80 artboards.",
  );
  if (job.documentId !== undefined)
    assert(
      typeof job.documentId === "string" && job.documentId.length <= 200,
      "Invalid document ID.",
    );
  const keys = new Set();
  let count = 0;
  function visit(node, depth) {
    assert(depth <= 12, "Node nesting is too deep.");
    assert(++count <= MAX_NODES, "Too many design nodes.");
    assert(node && TYPES.indexOf(node.type) !== -1, "Unsupported node type.");
    assert(
      typeof node.name === "string" && node.name.length <= 180,
      "Every node needs a short layer name.",
    );
    number(node.x, "Node x", -50000, 50000);
    number(node.y, "Node y", -50000, 50000);
    if (node.fill !== undefined) color(node.fill, "Fill");
    if (node.stroke !== undefined) {
      color(node.stroke, "Stroke");
      number(node.strokeWidth, "Stroke width", 0, 64);
    }
    if (node.opacity !== undefined) number(node.opacity, "Opacity", 0, 1);
    if (node.type === "group") {
      assert(
        Array.isArray(node.children) && node.children.length > 0,
        "Groups must contain layers.",
      );
      node.children.forEach((child) => visit(child, depth + 1));
    } else if (node.type === "text") {
      assert(
        typeof node.text === "string" && node.text.length <= 20000,
        "Invalid text content.",
      );
      assert(
        typeof node.fontFamily === "string" && node.fontFamily.length <= 100,
        "Text needs an explicit font family.",
      );
      assert(
        typeof node.fontStyle === "string" && node.fontStyle.length <= 100,
        "Text needs an explicit font style.",
      );
      number(node.fontSize, "Font size", 4, 500);
      if (node.width !== undefined) number(node.width, "Text width", 1, 50000);
      if (node.lineHeight !== undefined)
        number(node.lineHeight, "Line height", 1, 1000);
      if (node.letterSpacing !== undefined)
        number(node.letterSpacing, "Character spacing", -100, 100);
      if (node.align !== undefined)
        assert(
          ["left", "center", "right"].indexOf(node.align) !== -1,
          "Invalid text alignment.",
        );
    } else if (node.type === "path") {
      assert(
        typeof node.pathData === "string" &&
          node.pathData.length <= 200000 &&
          /^[MmLlHhVvCcSsQqTtAaZz0-9.,+\-\s]+$/.test(node.pathData),
        "Invalid vector path.",
      );
    } else {
      number(node.width, "Width", 1, 50000);
      number(node.height, "Height", 1, 50000);
      if (node.radius !== undefined)
        number(node.radius, "Radius", 0, Math.min(node.width, node.height) / 2);
      if (node.type === "image")
        assert(
          typeof node.dataUri === "string" &&
            /^data:image\/(png|jpeg|gif);base64,[A-Za-z0-9+/]+=*$/.test(
              node.dataUri,
            ) &&
            node.dataUri.length <= 12 * 1024 * 1024,
          "Images must be embedded PNG, JPEG or GIF data; remote URLs are not allowed.",
        );
    }
  }
  job.artboards.forEach((board) => {
    assert(
      board &&
        typeof board.key === "string" &&
        /^[a-z0-9][a-z0-9._-]{0,99}$/i.test(board.key),
      "Invalid artboard key.",
    );
    assert(!keys.has(board.key), "Duplicate artboard key.");
    keys.add(board.key);
    assert(
      typeof board.name === "string" && board.name.length <= 180,
      "Artboard needs a name.",
    );
    number(board.x, "Artboard x", -100000, 100000);
    number(board.y, "Artboard y", -100000, 100000);
    number(board.width, "Artboard width", 1, 50000);
    number(board.height, "Artboard height", 1, 50000);
    if (board.viewportHeight !== undefined)
      number(board.viewportHeight, "Viewport height", 1, board.height);
    color(board.fill, "Artboard fill");
    assert(Array.isArray(board.children), "Artboard children are required.");
    board.children.forEach((node) => visit(node, 0));
  });
  return { artboards: job.artboards.length, nodes: count };
}
module.exports = { validateJob };
