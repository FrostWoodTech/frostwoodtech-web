"use strict";
const sg = require("scenegraph");
const application = require("application");
const commands = require("commands");
const storage = require("uxp").storage;
const renderer = require("./renderer.js");
const BASE = "http://127.0.0.1:32189";
let panel,
  token = "",
  clientId = "",
  documentId = "",
  pending = null,
  timer = null,
  busy = false;
function message(value) {
  if (panel) panel.querySelector("#status").textContent = value;
}
function activeDocument() {
  const info = application.activeDocument;
  if (!info || !info.guid) throw new Error("Open an XD document first.");
  return { id: info.guid, name: info.name, version: application.version };
}
async function request(path, body) {
  const response = await fetch(BASE + path, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Bridge request failed.");
  return data;
}
function setReady(job) {
  pending = job;
  panel.querySelector("#apply").disabled = !job || busy;
  panel.querySelector("#batch").textContent = job
    ? job.label +
      " — " +
      job.summary.artboards +
      " artboards, " +
      job.summary.nodes +
      " layers"
    : "No changes waiting.";
}
async function poll() {
  if (!clientId || busy) return;
  const doc = activeDocument();
  if (doc.id !== documentId)
    throw new Error(
      "The connected document changed. Disconnect and reconnect in the intended file.",
    );
  const pollClientId = clientId;
  const result = await request(
    "/pending?clientId=" + encodeURIComponent(pollClientId),
  );
  if (busy || clientId !== pollClientId) return;
  setReady(result.job);
  message("Connected to “" + doc.name + "”. Changes require Apply.");
}
async function connect() {
  try {
    token = panel.querySelector("#token").value.trim();
    if (token.length < 32)
      throw new Error("Paste the pairing key from the local connection file.");
    const doc = activeDocument();
    const data = await request("/connect", {
      documentId: doc.id,
      name: doc.name,
      version: doc.version,
    });
    clientId = data.clientId;
    documentId = doc.id;
    panel.querySelector("#token").value = "";
    if (timer) clearInterval(timer);
    timer = setInterval(
      () => poll().catch((error) => message(error.message)),
      2000,
    );
    await poll();
  } catch (error) {
    message(error.message);
  }
}
function disconnect() {
  if (timer) clearInterval(timer);
  timer = null;
  token = "";
  clientId = "";
  documentId = "";
  setReady(null);
  message("Disconnected. No document changes can be applied.");
}
function apply() {
  if (!pending || busy) return;
  const job = pending;
  // This call is deliberately synchronous in the actual click handler. Timer callbacks never edit XD.
  busy = true;
  panel.querySelector("#apply").disabled = true;
  let operation;
  try {
    if (activeDocument().id !== documentId)
      throw new Error("Reconnect in the intended document.");
    // Fail before claiming a job when the user is drilled into an existing group/artboard.
    if (sg.selection.editContext !== sg.root)
      throw new Error(
        "Click blank pasteboard outside all artboards, then Apply.",
      );
    application.editDocument({ editLabel: job.label }, (selection, root) => {
      operation = request("/jobs/" + job.id + "/claim", {
        clientId: clientId,
      }).then(() => renderer.renderJob(job, root, selection, sg, commands));
      return operation;
    });
  } catch (error) {
    busy = false;
    panel.querySelector("#apply").disabled = false;
    message(error.message);
    return;
  }
  Promise.resolve(operation)
    .then(async (result) => {
      // Acknowledge before further reads. A lost acknowledgement never causes automatic re-application.
      await request("/jobs/" + job.id + "/complete", {
        clientId: clientId,
        result: result,
      });
      setReady(null);
      await publishSnapshot();
      message(
        "Applied “" +
          job.label +
          "”. Review the artboards; XD Undo can reverse this batch.",
      );
    })
    .catch(async (error) => {
      try {
        await request("/jobs/" + job.id + "/fail", {
          clientId: clientId,
          error: error.message,
        });
      } catch (_) {
        /* A claimed batch remains inspectable at the bridge. */
      }
      message(
        "Batch needs review: " +
          error.message +
          ". Check XD before sending another batch.",
      );
    })
    .then(() => {
      busy = false;
      panel.querySelector("#apply").disabled = !pending;
    });
}
async function publishSnapshot() {
  if (!clientId) throw new Error("Connect the document first.");
  return request("/snapshot", {
    clientId: clientId,
    documentId: documentId,
    nodes: renderer.snapshot(sg.root),
  });
}
function toBase64(buffer) {
  const bytes = new Uint8Array(buffer),
    alphabet =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let output = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const a = bytes[i],
      b = bytes[i + 1],
      c = bytes[i + 2];
    output +=
      alphabet[a >> 2] +
      alphabet[((a & 3) << 4) | ((b || 0) >> 4)] +
      (i + 1 < bytes.length
        ? alphabet[((b & 15) << 2) | ((c || 0) >> 6)]
        : "=") +
      (i + 2 < bytes.length ? alphabet[c & 63] : "=");
  }
  return output;
}
async function exportSelection() {
  if (busy) return;
  try {
    if (!clientId) throw new Error("Connect the document first.");
    const selected = sg.selection.items;
    if (selected.length !== 1 || !renderer.owned(selected[0]))
      throw new Error(
        "Select one bridge-created artboard, then Export preview.",
      );
    busy = true;
    const node = selected[0],
      folder = await storage.localFileSystem.getTemporaryFolder();
    const file = await folder.createFile(
      "frostwood-preview-" + Date.now() + ".png",
      { overwrite: false },
    );
    const scale = Math.min(1, 2400 / Math.max(node.width, node.height));
    await application.createRenditions([
      {
        node: node,
        outputFile: file,
        type: application.RenditionType.PNG,
        scale: Math.max(0.1, scale),
      },
    ]);
    const bytes = await file.read({ format: storage.formats.binary });
    await request("/preview", {
      clientId: clientId,
      documentId: documentId,
      nodeId: node.guid,
      key: node.pluginData.key,
      dataUri: "data:image/png;base64," + toBase64(bytes),
    });
    message(
      "Preview exported. I can now inspect this artboard through the local bridge.",
    );
  } catch (error) {
    message(error.message);
  } finally {
    busy = false;
    panel.querySelector("#apply").disabled = !pending;
  }
}
function show(event) {
  if (!panel) {
    panel = document.createElement("div");
    panel.innerHTML =
      '<style>.fw-panel{padding:12px}h2{font-size:17px;margin-bottom:12px}p{white-space:normal;margin:8px 0}input{width:100%}button{margin:5px 0;width:100%}.small{font-size:11px;color:#777}</style><div class="fw-panel"><h2>FrostWoodTech Design Bridge</h2><p>Connect this XD document to the bridge running on your computer.</p><label>Pairing key<input id="token" type="password" placeholder="Paste local pairing key" /></label><button id="connect" uxp-variant="cta">Connect document</button><button id="disconnect">Disconnect</button><p id="status">Not connected.</p><hr/><p id="batch">No changes waiting.</p><button id="apply" uxp-variant="cta" disabled>Apply queued design</button><button id="inspect">Send layer report</button><button id="preview">Export selected artboard preview</button><p class="small">Apply updates only bridge-created artboards. Manual artwork is preserved. Changes use XD Undo. This plugin does not save the document automatically.</p></div>';
    panel.querySelector("#connect").addEventListener("click", connect);
    panel.querySelector("#disconnect").addEventListener("click", disconnect);
    panel.querySelector("#apply").addEventListener("click", apply);
    panel.querySelector("#inspect").addEventListener("click", () =>
      publishSnapshot()
        .then(() => message("Layer report sent."))
        .catch((error) => message(error.message)),
    );
    panel.querySelector("#preview").addEventListener("click", exportSelection);
  }
  event.node.appendChild(panel);
}
function hide() {
  disconnect();
}
module.exports = { panels: { designBridge: { show: show, hide: hide } } };
