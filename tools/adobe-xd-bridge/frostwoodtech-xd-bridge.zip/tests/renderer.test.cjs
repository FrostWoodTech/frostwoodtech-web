"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { renderJob, snapshot, OWNER } = require("../plugin/renderer.js");
const example = require("../examples/connection-check.json");
let next = 0;
class SceneNode {
  constructor() {
    this.guid = String(++next);
    this.parent = null;
    this.name = "";
    this.position = { x: 0, y: 0 };
    this.pluginData = undefined;
  }
  get localBounds() {
    return { x: 0, y: 0, width: this.width || 10, height: this.height || 10 };
  }
  get globalBounds() {
    return {
      x: this.position.x,
      y: this.position.y,
      width: this.width || 10,
      height: this.height || 10,
    };
  }
  placeInParentCoordinates(_origin, point) {
    this.position = point;
  }
  removeFromParent() {
    if (this.parent) {
      this.parent.children = this.parent.children.filter((x) => x !== this);
      this.parent = null;
    }
  }
}
class Container extends SceneNode {
  constructor() {
    super();
    this.children = [];
  }
  addChild(n, index) {
    n.removeFromParent();
    n.parent = this;
    if (index === undefined) this.children.push(n);
    else this.children.splice(index, 0, n);
  }
}
class Artboard extends Container {}
class Group extends Container {}
class Rectangle extends SceneNode {
  setAllCornerRadii(value) {
    this.radius = value;
  }
}
class Ellipse extends SceneNode {}
class Path extends SceneNode {}
class Text extends SceneNode {
  set fontFamily(value) {
    if (value === "Missing Test Font") throw new Error("Missing font");
    this._fontFamily = value;
  }
  get fontFamily() {
    return this._fontFamily;
  }
}
Text.AUTO_HEIGHT = "auto-height";
Text.ALIGN_LEFT = "left";
Text.ALIGN_CENTER = "center";
Text.ALIGN_RIGHT = "right";
class Color {
  constructor(value) {
    this.value = value;
  }
}
class ImageFill {
  constructor(value) {
    this.dataUri = value;
  }
}
const sg = { Artboard, Rectangle, Ellipse, Path, Text, Color, ImageFill };
function setup() {
  const root = new Container(),
    selection = { editContext: root, items: [] };
  const commands = {
    group() {
      const nodes = selection.items,
        parent = nodes[0].parent;
      const group = new Group();
      parent.addChild(group);
      nodes.forEach((n) => group.addChild(n));
      selection.items = [group];
    },
  };
  return { root, selection, commands };
}
function clone() {
  return JSON.parse(JSON.stringify(example));
}
test("uses the native node API contract and replaces only bridge-owned artboards", () => {
  const { root, selection, commands } = setup();
  const manual = new Artboard();
  manual.name = "Manual design";
  root.addChild(manual);
  const first = renderJob(
    { ...clone(), id: "batch-1" },
    root,
    selection,
    sg,
    commands,
  );
  assert.equal(root.children.length, 3);
  assert.equal(first.artboards.length, 2);
  assert.equal(root.children[1].children[0] instanceof Text, true);
  assert.equal(root.children[1].children[0].layoutBox.type, Text.AUTO_HEIGHT);
  assert.equal(snapshot(root)[0].children[0].text, "FrostWoodTech");
  const second = renderJob(
    { ...clone(), id: "batch-2" },
    root,
    selection,
    sg,
    commands,
  );
  assert.equal(root.children.length, 3);
  assert.ok(root.children.includes(manual));
  assert.equal(second.replacedNodeIds.length, 2);
  assert.equal(root.children[1].pluginData.owner, OWNER);
});
test("preserves original artboards when font construction fails", () => {
  const { root, selection, commands } = setup();
  renderJob({ ...clone(), id: "first" }, root, selection, sg, commands);
  const original = root.children.slice(),
    job = clone();
  job.artboards[1].children[0].fontFamily = "Missing Test Font";
  assert.throws(
    () => renderJob(job, root, selection, sg, commands),
    /Missing font/,
  );
  assert.deepEqual(root.children, original);
});
test("rejects a narrowed XD edit context without changing the document", () => {
  const { root, selection, commands } = setup();
  selection.editContext = new Group();
  assert.throws(
    () => renderJob(clone(), root, selection, sg, commands),
    /blank pasteboard/,
  );
  assert.equal(root.children.length, 0);
});
test("groups through the native commands API and keeps nested offsets", () => {
  const { root, selection, commands } = setup(),
    job = clone();
  job.artboards = job.artboards.slice(0, 1);
  job.artboards[0].children = [
    {
      type: "group",
      name: "CTA component",
      x: 20,
      y: 30,
      children: [
        {
          type: "rect",
          name: "Fill",
          x: 5,
          y: 6,
          width: 200,
          height: 48,
          fill: "#72F4DC",
        },
        {
          type: "text",
          name: "Label",
          x: 15,
          y: 16,
          text: "Editable",
          fontFamily: "Arial",
          fontStyle: "Bold",
          fontSize: 18,
          fill: "#031D1A",
        },
      ],
    },
  ];
  renderJob(job, root, selection, sg, commands);
  const group = root.children[0].children[0];
  assert.equal(group instanceof Group, true);
  assert.equal(group.name, "CTA component");
  assert.deepEqual(group.children[0].position, { x: 25, y: 36 });
});
