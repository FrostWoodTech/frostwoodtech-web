"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { startBridge } = require("../server.cjs");
const { validateJob } = require("../plugin/protocol.js");
const example = require("../examples/connection-check.json");
const copy = (value) => JSON.parse(JSON.stringify(value));
test("declarative batches validate and reject executable/remote/invalid design data", () => {
  assert.deepEqual(validateJob(example), { artboards: 2, nodes: 19 });
  for (const mutate of [
    (j) => (j.kind = "eval"),
    (j) => (j.artboards[0].width = -10),
    (j) => (j.artboards[0].children[0].type = "javascript"),
    (j) => j.artboards.push(copy(j.artboards[0])),
    (j) => (j.artboards[0].children[0].fill = "url(https://example.com)"),
  ]) {
    const job = copy(example);
    mutate(job);
    assert.throws(() => validateJob(job));
  }
  const job = copy(example);
  job.artboards[0].children = [
    {
      type: "image",
      name: "remote",
      x: 0,
      y: 0,
      width: 10,
      height: 10,
      dataUri: "https://example.com/image.png",
    },
  ];
  assert.throws(() => validateJob(job), /embedded/);
});
test("authenticated loopback queue enforces document ownership, one claim, and read-back", async (t) => {
  const { server, session } = await startBridge({ port: 0 });
  t.after(
    () =>
      new Promise((resolve) => {
        server.close(resolve);
        server.closeAllConnections();
      }),
  );
  const call = async (route, body, extra = {}) =>
    fetch(session.baseUrl + route, {
      method: body === undefined ? "GET" : "POST",
      headers: {
        Authorization: "Bearer " + session.token,
        "Content-Type": "application/json",
        ...extra,
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  assert.equal((await fetch(session.baseUrl + "/status")).status, 401);
  assert.equal(
    (await call("/status", undefined, { Origin: "https://untrusted.example" }))
      .status,
    403,
  );
  const badHostStatus = await new Promise((resolve, reject) => {
    const req = require("node:http").request(
      session.baseUrl + "/status",
      {
        headers: {
          Host: "attacker.example",
          Authorization: "Bearer " + session.token,
        },
      },
      (res) => {
        res.resume();
        resolve(res.statusCode);
      },
    );
    req.on("error", reject);
    req.end();
  });
  assert.equal(badHostStatus, 403);
  const a = await (
    await call("/connect", { documentId: "doc-a", name: "Website.xd" })
  ).json();
  const b = await (
    await call("/connect", { documentId: "doc-b", name: "Other.xd" })
  ).json();
  const job = await (
    await call("/jobs", { ...example, documentId: "doc-a" })
  ).json();
  assert.equal(job.status, "queued");
  assert.equal(
    (await (await call("/pending?clientId=" + b.clientId)).json()).job,
    null,
  );
  assert.equal(
    (await (await call("/pending?clientId=" + a.clientId)).json()).job.id,
    job.id,
  );
  assert.equal(
    (await call("/jobs/" + job.id + "/claim", { clientId: b.clientId })).status,
    409,
  );
  assert.equal(
    (await call("/jobs/" + job.id + "/claim", { clientId: a.clientId })).status,
    200,
  );
  assert.equal(
    (await call("/jobs/" + job.id + "/claim", { clientId: a.clientId })).status,
    409,
  );
  assert.equal(
    (await call("/jobs/" + job.id + "/complete", { clientId: b.clientId }))
      .status,
    409,
  );
  assert.equal(
    (
      await call("/jobs/" + job.id + "/complete", {
        clientId: a.clientId,
        result: { createdNodeIds: ["native-1"] },
      })
    ).status,
    200,
  );
  assert.equal(
    (await (await call("/jobs/" + job.id)).json()).status,
    "completed",
  );
  assert.equal(
    (await (await call("/pending?clientId=" + a.clientId)).json()).job,
    null,
  );
  await call("/snapshot", {
    clientId: a.clientId,
    documentId: "doc-a",
    nodes: [{ id: "native-1", type: "Text", text: "Editable" }],
  });
  assert.equal(
    (await (await call("/snapshot?clientId=" + a.clientId)).json()).nodes[0]
      .text,
    "Editable",
  );
  assert.equal(
    (
      await call("/snapshot", {
        clientId: a.clientId,
        documentId: "doc-b",
        nodes: [],
      })
    ).status,
    400,
  );
  assert.equal(
    (await call("/jobs", { kind: "execute", code: "anything" })).status,
    400,
  );
  assert.equal(
    (
      await call("/preview", {
        clientId: a.clientId,
        documentId: "doc-a",
        nodeId: "native-1",
        key: "test",
        dataUri: "data:image/png;base64,YmFk",
      })
    ).status,
    400,
  );
  const png = Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aOwAAAABJRU5ErkJggg==",
    "base64",
  );
  const uploaded = await (
    await call("/preview", {
      clientId: a.clientId,
      documentId: "doc-a",
      nodeId: "native-1",
      key: "test",
      dataUri: "data:image/png;base64," + png.toString("base64"),
    })
  ).json();
  const downloaded = Buffer.from(
    await (await call("/previews/" + uploaded.id)).arrayBuffer(),
  );
  assert.deepEqual(downloaded, png);
});
