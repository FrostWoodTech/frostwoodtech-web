"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict"),
  vm = require("node:vm"),
  fs = require("node:fs"),
  path = require("node:path");
test("XD applies only from the click handler, awaits the claim, and never re-applies while busy", async () => {
  const elements = {},
    calls = [],
    job = {
      id: "batch",
      label: "Connection check",
      summary: { artboards: 2, nodes: 19 },
    };
  const element = (id) =>
    elements[id] ||
    (elements[id] = {
      value: "",
      disabled: false,
      textContent: "",
      addEventListener(name, fn) {
        this[name] = fn;
      },
    });
  const panel = { innerHTML: "", querySelector: (id) => element(id) };
  let poll,
    claimResolve,
    edits = 0,
    renders = 0;
  const root = {},
    sg = { root, selection: { editContext: root, items: [] } };
  const application = {
    activeDocument: { guid: "doc", name: "Untitled" },
    version: "57.0",
    editDocument(_options, callback) {
      edits++;
      callback(
        sg.selection,
        root,
      ); /* XD need not return the callback promise. */
    },
  };
  const context = {
    module: { exports: {} },
    document: { createElement: () => panel },
    setInterval: (callback) => {
      poll = callback;
      return 1;
    },
    clearInterval: () => {},
    fetch: async (url, options) => {
      const route = new URL(url).pathname;
      calls.push(route);
      let data;
      if (route === "/connect") data = { clientId: "client" };
      else if (route === "/pending") data = { job };
      else if (route.endsWith("/claim"))
        return new Promise((resolve) => {
          claimResolve = () =>
            resolve({ ok: true, json: async () => ({ status: "running" }) });
        });
      else data = { ok: true };
      return { ok: true, json: async () => data };
    },
    require: (name) =>
      ({
        scenegraph: sg,
        application,
        commands: {},
        uxp: { storage: {} },
        "./renderer.js": {
          renderJob: () => {
            renders++;
            return { createdNodeIds: ["1"] };
          },
          snapshot: () => [],
        },
      })[name],
  };
  vm.runInNewContext(
    fs.readFileSync(path.join(__dirname, "../plugin/main.js"), "utf8"),
    context,
  );
  context.module.exports.panels.designBridge.show({
    node: { appendChild() {} },
  });
  element("#token").value = "a".repeat(64);
  await element("#connect").click();
  assert.equal(edits, 0);
  assert.equal(element("#apply").disabled, false);
  assert.equal(element("#token").value, "");
  await poll();
  assert.equal(edits, 0);
  element("#apply").click();
  assert.equal(edits, 1);
  assert.equal(renders, 0);
  element("#apply").click();
  assert.equal(edits, 1);
  await new Promise((resolve) => setImmediate(resolve));
  claimResolve();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(renders, 1);
  assert.ok(calls.includes("/jobs/batch/complete"));
  assert.ok(calls.includes("/snapshot"));
  assert.equal(element("#apply").disabled, true);
});
