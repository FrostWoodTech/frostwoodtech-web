"use strict";
const fs = require("node:fs/promises");
const path = require("node:path");
async function main() {
  const [command, argument, target] = process.argv.slice(2);
  const session = JSON.parse(
    await fs.readFile(path.join(__dirname, ".local/session.json"), "utf8"),
  );
  const headers = {
    Authorization: "Bearer " + session.token,
    "Content-Type": "application/json",
  };
  let route = "/status",
    body;
  if (command === "queue") {
    route = "/jobs";
    body = JSON.parse(
      (await fs.readFile(path.resolve(argument), "utf8")).replace(
        /^\uFEFF/,
        "",
      ),
    );
  } else if (command === "job") route = "/jobs/" + encodeURIComponent(argument);
  else if (command === "snapshot")
    route = "/snapshot?clientId=" + encodeURIComponent(argument);
  else if (command === "preview")
    route = "/previews/" + encodeURIComponent(argument);
  else if (command !== "status")
    throw new Error(
      "Usage: node cli.cjs status | queue batch.json | job ID | snapshot CLIENT_ID | preview PREVIEW_ID output.png",
    );
  const response = await fetch(session.baseUrl + route, {
    method: body === undefined ? "GET" : "POST",
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || "Bridge request failed.");
  }
  if (command === "preview") {
    if (!target) throw new Error("Supply an output PNG path.");
    await fs.writeFile(
      path.resolve(target),
      Buffer.from(await response.arrayBuffer()),
      { flag: "wx" },
    );
    console.log("Preview saved to " + path.resolve(target));
  } else console.log(JSON.stringify(await response.json(), null, 2));
}
main().catch((error) => {
  console.error("XD bridge: " + error.message);
  process.exitCode = 1;
});
