# FrostWoodTech Adobe XD bridge

A local development plugin and companion server for creating native editable XD artboards, text, shapes, paths, image fills, and groups from declarative design batches. The companion CLI lets the assistant queue changes, read bridge-owned layers, and retrieve artboard preview images without adding a new Codex MCP connection.

Status: protocol, server, panel-control, and rendering contract tests pass. **Not yet loaded or validated in Adobe XD.** The user has UXP Developer Tool installed, but Adobe XD itself is not installed yet. This package is ready for that first native-host connection check; it is not a completed website design.

## Set up

1. Install Adobe XD using your Creative Cloud account and open a new, blank XD document. Adobe must make XD available to your account; UXP Developer Tool alone is not the XD host.
2. Start the bridge by opening `Start-Bridge.cmd` in this folder. It uses Node.js 22 or later, already available in this workspace. Keep its terminal running. No dependency installation is required.
3. In **UXP Developer Tool → Add Plugin**, select `plugin/manifest.json`. With Adobe XD running, choose **Load** for this plugin. Approve Adobe's Developer Mode prompt if the tool asks; the assistant has not changed your system developer settings.
4. In XD, open **Plugins → FrostWoodTech Design Bridge**. Open `.local/connection.local.txt` on your computer and copy the pairing key into the plugin panel. Click **Connect document**. Keep this panel open. Do not paste the key into chat.
5. Click the blank pasteboard outside all artboards. When the connection-check batch is waiting, click **Apply queued design**. If no batch is waiting, the assistant can queue it using the command below. Two small native test artboards should appear, labelled as connection checks. They do not redesign the existing homepage.
6. Select one generated artboard and click **Export selected artboard preview**. Click **Send layer report** to send its editable layer structure. The assistant can then inspect actual XD output and refine the plugin if the native host exposes a compatibility issue.
7. Save the document using XD when you want to keep it. The plugin does not automatically save, publish, or upload it.

The manifest uses the local development identifier `FWTXDB01`. It is not a registered Marketplace ID. If your Adobe developer workflow requires an Adobe-issued ID, use the ID for your own development plugin in `plugin/manifest.json` before the first design batch. Adobe's quick-start describes obtaining an ID in the Developer Console. Do not change the ID after starting a document: XD isolates persisted plugin metadata by plugin ID.

Adobe no longer accepts new XD Marketplace plugins, but its current documentation says UXP Developer Tool continues to support development. This package is loaded locally; it does not publish to the Marketplace.

## Why Apply is required

XD permits `application.editDocument()` only in response to an actual panel UI event. The queue timer only reads pending work. The Apply click opens an edit batch synchronously and then awaits the local queue claim before creating any nodes. The plugin never synthesizes a click or tries to edit from its polling timer.

One click can apply a batch of multiple artboards. This is an assisted connection, not unattended control equivalent to Figma's remote editing tool. XD's edit-context restrictions also apply: click blank pasteboard before applying changes. Normal XD Undo can reverse the applied edit batch.

## Assistant commands

Run these from `tools/adobe-xd-bridge`:

```powershell
node server.cjs
node cli.cjs status
node cli.cjs queue examples/connection-check.json
node cli.cjs job BATCH_ID
node cli.cjs snapshot CLIENT_ID
node cli.cjs preview PREVIEW_ID preview.png
node --test tests/*.test.cjs
```

`status` reports connected document identities, batch statuses, and available previews. Queue results do not imply that changes reached XD. Only a completed batch plus an XD layer report and preview establishes that the native design exists.

If the server restarts, reconnect the plugin using the new local pairing key. Queue state is in memory and does not survive a restart. A new bridge workspace is placed to the right of existing artwork. Existing bridge artboards retain their stable keys and workspace origin in XD; updating a matching key replaces only that bridge-owned artboard. Other manually created artwork is preserved. Changes made by hand inside a bridge-owned artboard will be replaced when that artboard is rebuilt; duplicate it before further manual customization if you need to preserve an independent version.

A claimed batch is never automatically replayed. If acknowledgement is lost, inspect XD before queueing a new batch. When duplicate bridge keys exist after manual copying, the renderer stops rather than choosing an arbitrary artboard.

## Supported design protocol

See `examples/connection-check.json` for a complete desktop/mobile example.

- Batch: `kind: "render"`, descriptive `label`, optional target `documentId`, and `artboards`.
- Artboard: stable `key`, name, x/y, width/height, hex background fill, optional viewport height, children.
- Layer types: `rect`, `ellipse`, `text`, `path`, `image`, `group`.
- Text: explicit family/style/size, content, optional auto-height width, line height, character spacing and alignment. Text remains an XD Text node.
- Images: embedded PNG/JPEG/GIF data URIs, drawn as XD image fills. Convert the website's WebP assets before using them; WebP is not an XD ImageFill format.
- Groups: created using XD's `commands.group()`, not unsupported Group constructors.

This first bridge does not yet expose XD component creation, shared-library synchronization, auto-layout, or prototype interactions. Those require separate supported XD API work and native-host verification. Do not claim those capabilities from successful primitive rendering.

The connection-check sample uses Arial to avoid requiring Manrope before the first test. It is explicitly not the homepage design. Actual FrostWoodTech page designs must use the existing Manrope typeface and original generated artwork; font fidelity must be checked from actual XD layer reports and screenshots.

## Local access

The server binds only to `127.0.0.1:32189`. Every endpoint requires a fresh per-run pairing key. Browser web origins are rejected. The protocol accepts design primitives only: it has no arbitrary JavaScript evaluation, shell execution, remote asset fetching, or general filesystem endpoints. Plugin storage holds temporary preview exports only. Pairing files stay in the ignored `.local/` directory and are excluded from the distribution ZIP.

## Verification completed

Seven tests pass:

- Invalid geometry, unsupported command types, remote image URLs, and duplicate keys are rejected.
- Real loopback HTTP tests verify pairing authentication, origin/Host restrictions, document ownership, single-claim semantics, completion state, snapshots, and PNG preview transfer.
- A panel controller test verifies that polling never edits, Apply initiates editing from the click handler, a delayed claim is awaited, and repeated clicks cannot apply a busy batch twice.
- Native API contract mocks verify editable text construction, managed-artboard replacement, preservation of unrelated artwork, construction-failure cleanup, edit-context rejection, and grouping through the commands API.

Mock tests do **not** establish XD host compatibility, font fidelity, visual quality, Undo behavior, or UXP networking on the user's installed version. Those remain pending until XD is installed and the connection-check batch is applied and inspected.

## Adobe references

- [XD plugin development and current distribution status](https://developer.adobe.com/xd/uxp/develop/)
- [UXP Developer Tool for XD](https://developer.adobe.com/xd/uxp/develop/plugin-development/devtool/)
- [Add a plugin to UXP Developer Tool](https://developer.adobe.com/uxp/guides/how-to/udt-deep-dive/plugin-management)
- [XD editDocument and rendition APIs](https://developer.adobe.com/xd/uxp/develop/reference/application/)
- [Native XD scenegraph](https://developer.adobe.com/xd/uxp/develop/reference/scenegraph/)
- [XD group creation restrictions](https://developer.adobe.com/xd/uxp/develop/reference/group)
- [XD image fills](https://developer.adobe.com/xd/uxp/develop/reference/image-fill)
